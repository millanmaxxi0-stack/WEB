import os
import json
import uuid
import socket
import shutil
import signal
import zipfile
import threading
import subprocess
from flask import Flask, request, jsonify, render_template, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APPS_DIR = os.path.join(BASE_DIR, "deployed_apps")
DB_FILE = os.path.join(BASE_DIR, "apps_db.json")
PORT_RANGE_START = 6000
PORT_RANGE_END = 6999

os.makedirs(APPS_DIR, exist_ok=True)
if not os.path.exists(DB_FILE):
    with open(DB_FILE, "w") as f:
        json.dump([], f)

db_lock = threading.Lock()
app = Flask(__name__)


# ---------- کمکی‌ها برای دیتابیس ساده (JSON) ----------

def load_db():
    with db_lock:
        with open(DB_FILE) as f:
            return json.load(f)


def save_db(records):
    with db_lock:
        with open(DB_FILE, "w") as f:
            json.dump(records, f, indent=2, ensure_ascii=False)


def get_app_record(app_id):
    for r in load_db():
        if r["id"] == app_id:
            return r
    return None


def update_record(app_id, **kwargs):
    records = load_db()
    for r in records:
        if r["id"] == app_id:
            r.update(kwargs)
    save_db(records)


def find_free_port():
    used = {r["port"] for r in load_db()}
    for p in range(PORT_RANGE_START, PORT_RANGE_END):
        if p in used:
            continue
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    raise RuntimeError("پورت آزاد پیدا نشد")


def is_pid_running(pid):
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# ---------- تشخیص نوع پروژه و اجرا ----------

def detect_type(path):
    if os.path.exists(os.path.join(path, "requirements.txt")) or \
       os.path.exists(os.path.join(path, "app.py")) or \
       os.path.exists(os.path.join(path, "main.py")):
        return "python"
    if os.path.exists(os.path.join(path, "package.json")) or \
       os.path.exists(os.path.join(path, "index.js")) or \
       os.path.exists(os.path.join(path, "server.js")):
        return "node"
    return "unknown"


def run_step(cmd, cwd, log_path, label):
    """یک دستور را اجرا می‌کند، خروجی را در لاگ می‌نویسد و کد خروجی + متن را برمی‌گرداند."""
    with open(log_path, "a") as f:
        f.write(f"\n### {label}\n$ {' '.join(cmd)}\n")
    result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True)
    with open(log_path, "a") as f:
        f.write(result.stdout or "")
    return result.returncode, result.stdout or ""


def pip_install(req_path, cwd, log_path):
    code, out = run_step(["pip", "install", "-r", req_path], cwd, log_path, "نصب requirements.txt")
    if code != 0 and "externally-managed-environment" in out:
        # مشکل شناخته‌شده در پایتون‌های جدید (از جمله ترموکس) - با فلگ زیر حل می‌شود
        code, out = run_step(["pip", "install", "--break-system-packages", "-r", req_path],
                              cwd, log_path, "تلاش دوباره با --break-system-packages")
    if code != 0:
        raise RuntimeError("نصب پکیج‌های پایتون شکست خورد. لاگ کامل را ببین.")


def npm_install(cwd, log_path):
    code, out = run_step(["npm", "install"], cwd, log_path, "npm install")
    if code != 0:
        raise RuntimeError("npm install شکست خورد. مطمئن شو nodejs نصب است (pkg install nodejs).")


def detect_node_start_cmd(path):
    pkg_path = os.path.join(path, "package.json")
    if os.path.exists(pkg_path):
        try:
            with open(pkg_path) as f:
                pkg = json.load(f)
            if "start" in pkg.get("scripts", {}):
                return ["npm", "start"], True
        except (json.JSONDecodeError, OSError):
            pass
    for entry in ("server.js", "index.js", "main.js", "app.js"):
        if os.path.exists(os.path.join(path, entry)):
            return ["node", entry], os.path.exists(pkg_path)
    raise RuntimeError("هیچ فایل ورودی (index.js/server.js/app.js) یا اسکریپت start پیدا نشد.")


def build_and_run(app_id):
    record = get_app_record(app_id)
    path = record["path"]
    log_path = os.path.join(path, "build.log")
    open(log_path, "w").close()

    try:
        update_record(app_id, status="building", error=None)
        app_type = detect_type(path)
        update_record(app_id, type=app_type)

        if app_type == "python":
            req = os.path.join(path, "requirements.txt")
            if os.path.exists(req):
                pip_install(req, path, log_path)
            entry = "app.py" if os.path.exists(os.path.join(path, "app.py")) else "main.py"
            if not os.path.exists(os.path.join(path, entry)):
                raise RuntimeError("فایل app.py یا main.py در پروژه پیدا نشد.")
            cmd = ["python", entry]

        elif app_type == "node":
            cmd, needs_install = detect_node_start_cmd(path)
            if needs_install:
                npm_install(path, log_path)
        else:
            raise RuntimeError("نوع پروژه شناسایی نشد. باید requirements.txt/app.py (پایتون) یا package.json/index.js (Node.js) داشته باشد.")

        update_record(app_id, cmd=cmd, status="starting")
        start_process(app_id)

    except RuntimeError as e:
        update_record(app_id, status="failed", error=str(e))
    except Exception as e:
        update_record(app_id, status="failed", error=f"خطای غیرمنتظره: {e}")
        with open(log_path, "a") as f:
            f.write(f"\n### خطای غیرمنتظره: {e}\n")


def start_process(app_id):
    record = get_app_record(app_id)
    path = record["path"]
    log_path = os.path.join(path, "build.log")
    env = os.environ.copy()
    env["PORT"] = str(record["port"])

    with open(log_path, "a") as log_f:
        log_f.write(f"### اجرا روی پورت {record['port']} ...\n")
        proc = subprocess.Popen(record["cmd"], cwd=path, stdout=log_f,
                                 stderr=subprocess.STDOUT, env=env)
    update_record(app_id, status="running", pid=proc.pid)


def stop_process(app_id):
    record = get_app_record(app_id)
    pid = record.get("pid")
    if pid and is_pid_running(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    update_record(app_id, status="stopped", pid=None)


# ---------- روت‌ها ----------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/apps")
def api_apps():
    records = load_db()
    for r in records:
        if r["status"] == "running" and not is_pid_running(r.get("pid")):
            r["status"] = "crashed"
    save_db(records)
    return jsonify(records)


@app.route("/api/deploy", methods=["POST"])
def api_deploy():
    file = request.files.get("file")
    name = request.form.get("name", "").strip() or "app"
    if not file or not file.filename.endswith(".zip"):
        return jsonify({"error": "لطفاً یک فایل zip آپلود کن"}), 400

    app_id = uuid.uuid4().hex[:8]
    project_dir = os.path.join(APPS_DIR, app_id)
    os.makedirs(project_dir, exist_ok=True)

    zip_path = os.path.join(project_dir, "upload.zip")
    file.save(zip_path)

    with zipfile.ZipFile(zip_path) as z:
        z.extractall(project_dir)
    os.remove(zip_path)

    # اگر همه‌چیز داخل یک زیرپوشه بود، آن را بالا بیاور
    entries = [e for e in os.listdir(project_dir) if not e.startswith(".")]
    if len(entries) == 1 and os.path.isdir(os.path.join(project_dir, entries[0])):
        inner = os.path.join(project_dir, entries[0])
        for item in os.listdir(inner):
            shutil.move(os.path.join(inner, item), project_dir)
        os.rmdir(inner)

    port = find_free_port()
    record = {
        "id": app_id,
        "name": name,
        "path": project_dir,
        "port": port,
        "status": "queued",
        "pid": None,
        "cmd": None,
        "type": None,
        "error": None,
    }
    records = load_db()
    records.append(record)
    save_db(records)

    threading.Thread(target=build_and_run, args=(app_id,), daemon=True).start()
    return jsonify(record)


@app.route("/api/apps/<app_id>/stop", methods=["POST"])
def api_stop(app_id):
    if not get_app_record(app_id):
        return jsonify({"error": "پیدا نشد"}), 404
    stop_process(app_id)
    return jsonify({"ok": True})


@app.route("/api/apps/<app_id>/start", methods=["POST"])
def api_start(app_id):
    record = get_app_record(app_id)
    if not record:
        return jsonify({"error": "پیدا نشد"}), 404
    if not record.get("cmd"):
        threading.Thread(target=build_and_run, args=(app_id,), daemon=True).start()
    else:
        threading.Thread(target=start_process, args=(app_id,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/apps/<app_id>/rebuild", methods=["POST"])
def api_rebuild(app_id):
    record = get_app_record(app_id)
    if not record:
        return jsonify({"error": "پیدا نشد"}), 404
    stop_process(app_id)
    threading.Thread(target=build_and_run, args=(app_id,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/apps/<app_id>/delete", methods=["POST"])
def api_delete(app_id):
    record = get_app_record(app_id)
    if not record:
        return jsonify({"error": "پیدا نشد"}), 404
    stop_process(app_id)
    shutil.rmtree(record["path"], ignore_errors=True)
    records = [r for r in load_db() if r["id"] != app_id]
    save_db(records)
    return jsonify({"ok": True})


@app.route("/api/apps/<app_id>/logs")
def api_logs(app_id):
    record = get_app_record(app_id)
    if not record:
        return jsonify({"error": "پیدا نشد"}), 404
    log_path = os.path.join(record["path"], "build.log")
    if not os.path.exists(log_path):
        return jsonify({"logs": ""})
    with open(log_path, errors="ignore") as f:
        content = f.read()
    return jsonify({"logs": content[-8000:]})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)
