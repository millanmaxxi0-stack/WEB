const appsList = document.getElementById("appsList");
const deployBtn = document.getElementById("deployBtn");
const deployStatus = document.getElementById("deployStatus");
const logsModal = document.getElementById("logsModal");
const logsContent = document.getElementById("logsContent");
const logsTitle = document.getElementById("logsTitle");
const zipFile = document.getElementById("zipFile");
const fileLabelText = document.getElementById("fileLabelText");
const dropZone = document.getElementById("dropZone");

const statusLabels = {
  queued: "در صف", building: "در حال Build", starting: "در حال اجرا شدن",
  running: "در حال اجرا", stopped: "متوقف", failed: "خطا", crashed: "کرش کرده",
};
const liveStates = ["queued", "building", "starting"];

zipFile.addEventListener("change", () => {
  fileLabelText.textContent = zipFile.files.length ? zipFile.files[0].name : "یک فایل zip انتخاب کن یا اینجا رها کن";
});

["dragover", "dragleave", "drop"].forEach(evt => {
  dropZone.addEventListener(evt, (e) => e.preventDefault());
});
dropZone.addEventListener("drop", (e) => {
  const file = e.dataTransfer.files[0];
  if (file && file.name.endsWith(".zip")) {
    zipFile.files = e.dataTransfer.files;
    fileLabelText.textContent = file.name;
  }
});

deployBtn.addEventListener("click", async () => {
  const name = document.getElementById("appName").value;
  if (!zipFile.files.length) {
    deployStatus.textContent = "یک فایل zip انتخاب کن.";
    return;
  }

  const formData = new FormData();
  formData.append("file", zipFile.files[0]);
  formData.append("name", name);

  deployBtn.disabled = true;
  deployStatus.textContent = "در حال آپلود...";

  try {
    const res = await fetch("/api/deploy", { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      deployStatus.textContent = "خطا: " + data.error;
    } else {
      deployStatus.textContent = "آپلود شد! در حال Build... (پایین را ببین)";
      zipFile.value = "";
      fileLabelText.textContent = "یک فایل zip انتخاب کن یا اینجا رها کن";
      document.getElementById("appName").value = "";
    }
  } catch (err) {
    deployStatus.textContent = "خطا در ارتباط با سرور.";
  } finally {
    deployBtn.disabled = false;
    loadApps();
  }
});

async function loadApps() {
  const res = await fetch("/api/apps");
  const apps = await res.json();
  appsList.innerHTML = "";

  if (apps.length === 0) {
    appsList.innerHTML = '<p style="color:#64748b;">هنوز پروژه‌ای آپلود نکردی.</p>';
    return;
  }

  apps.reverse().forEach(app => {
    const card = document.createElement("div");
    card.className = "app-card";
    const isLive = liveStates.includes(app.status);
    const link = app.status === "running"
      ? `<a href="http://127.0.0.1:${app.port}" target="_blank">http://127.0.0.1:${app.port} ↗</a>`
      : `پورت رزرو‌شده: ${app.port}`;

    card.innerHTML = `
      <div class="app-card-top">
        <h3>${app.name}</h3>
        <span class="badge ${app.status} ${isLive ? "pulse" : ""}">${statusLabels[app.status] || app.status}</span>
      </div>
      <div class="app-meta">نوع: ${app.type || "در حال تشخیص..."} | ${link}</div>
      ${app.error ? `<div class="error-box">${app.error}</div>` : ""}
      <div class="app-actions">
        <button data-action="logs" data-id="${app.id}">📄 لاگ‌ها</button>
        ${app.status === "running"
          ? `<button data-action="stop" data-id="${app.id}">⏸ توقف</button>`
          : `<button class="primary" data-action="start" data-id="${app.id}">▶ اجرا</button>`}
        <button data-action="rebuild" data-id="${app.id}">🔁 Build دوباره</button>
        <button class="danger" data-action="delete" data-id="${app.id}">🗑 حذف</button>
      </div>
    `;
    appsList.appendChild(card);
  });
}

appsList.addEventListener("click", async (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const { action, id } = btn.dataset;

  if (action === "logs") {
    const res = await fetch(`/api/apps/${id}/logs`);
    const data = await res.json();
    logsTitle.textContent = "لاگ‌ها";
    logsContent.textContent = data.logs || "لاگی موجود نیست.";
    logsModal.classList.remove("hidden");
    return;
  }

  if (action === "delete" && !confirm("مطمئنی می‌خواهی این پروژه را حذف کنی؟")) return;

  btn.disabled = true;
  await fetch(`/api/apps/${id}/${action}`, { method: "POST" });
  loadApps();
});

document.getElementById("closeLogs").addEventListener("click", () => {
  logsModal.classList.add("hidden");
});

// اگر مودال لاگ‌ها باز است و پروژه در حال build است، لاگ را زنده به‌روز کن
setInterval(() => {
  if (!logsModal.classList.contains("hidden")) {
    // نگه‌داشتن اسکرول پایین هنگام آپدیت زنده در آینده قابل اضافه شدن است
  }
}, 2000);

loadApps();
setInterval(loadApps, 2500);
